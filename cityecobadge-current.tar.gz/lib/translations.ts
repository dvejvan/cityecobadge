// Re-export from modular translation system
export { translations, getTranslation, type Translations } from './translations/index';